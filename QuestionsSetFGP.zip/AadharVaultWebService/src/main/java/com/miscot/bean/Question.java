package com.miscot.bean;

public class Question {
	private String ID;
	private String QUESTION_TEXT;
	private String ANSWER_DATATYPE;
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getQUESTION_TEXT() {
		return QUESTION_TEXT;
	}
	
	
	
	public void setQUESTION_TEXT(String qUESTION_TEXT) {
		QUESTION_TEXT = qUESTION_TEXT;
	}
	public String getANSWER_DATATYPE() {
		return ANSWER_DATATYPE;
	}
	public void setANSWER_DATATYPE(String aNSWER_DATATYPE) {
		ANSWER_DATATYPE = aNSWER_DATATYPE;
	}
	

}
