package com.miscot.bean;

public class UserMasterBean {
	
	private String id;
	private String name;
	private String age;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getAns1() {
		return Ans1;
	}
	public void setAns1(String ans1) {
		Ans1 = ans1;
	}
	public String getAns2() {
		return Ans2;
	}
	public void setAns2(String ans2) {
		Ans2 = ans2;
	}
	public String getAns3() {
		return Ans3;
	}
	public void setAns3(String ans3) {
		Ans3 = ans3;
	}
	private String Ans1;
	private String Ans2;
	private String Ans3;
	
	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
/*private String UserName;
private String UserID;
private String page;
private String rows;


private String txtUserID;
private String txtUserName;
private String selUserStatus;
private String selUserRole;
private String txtExpiryDate;
private String txtP_F_Number;
private String txtSolID;
private String txtPassword;
private String chkApp;
private String chkFolder;
private int count;

private String USER_STATUS;
private String USER_ROLE;
private String USER_ROLE_DESC;


private String CREATED_TIME;
private String CREATED_USER;
private String LAST_LOGIN_DATE;
private String LAST_LOGIN_IP;
private String LOGIN_STATUS;
private String LOGIN_RESET;
private String MODIFIED_USER;
private String MODIFIED_TIME;
private String USER_VERIFY;
private String USER_HISTORY;
private String ISVERIFIED;
private String EXPIRY_DATE;
private String User_status_desc;
private String P_F_NNUMBER;
private String SOL_ID;
private String PASSWORD;
private String PASSWORD_RESET;
private String txt_User_id;
private String chkUserID;


private String fromdate;
private String todate;
private String status;
private String user_id_acted_on;
private String fileType;

private String ques1;
private String ques2;
private String ques3;
private String Ans1;
public String getQues1() {
	return ques1;
}
public void setQues1(String ques1) {
	this.ques1 = ques1;
}
public String getQues2() {
	return ques2;
}
public void setQues2(String ques2) {
	this.ques2 = ques2;
}
public String getQues3() {
	return ques3;
}
public void setQues3(String ques3) {
	this.ques3 = ques3;
}
public String getAns1() {
	return Ans1;
}
public void setAns1(String ans1) {
	Ans1 = ans1;
}
public String getAns2() {
	return Ans2;
}
public void setAns2(String ans2) {
	Ans2 = ans2;
}
public String getAns3() {
	return Ans3;
}
public void setAns3(String ans3) {
	Ans3 = ans3;
}
private String Ans2;
private String Ans3;

public String getFileType() {
	return fileType;
}
public void setFileType(String fileType) {
	this.fileType = fileType;
}
public String getUser_id_acted_on() {
	return user_id_acted_on;
}
public void setUser_id_acted_on(String user_id_acted_on) {
	this.user_id_acted_on = user_id_acted_on;
}
public String getFromdate() {
	return fromdate;
}
public void setFromdate(String fromdate) {
	this.fromdate = fromdate;
}
public String getTodate() {
	return todate;
}
public void setTodate(String todate) {
	this.todate = todate;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getChkUserID() {
	return chkUserID;
}
public void setChkUserID(String chkUserID) {
	this.chkUserID = chkUserID;
}
public String getTxt_User_id() {
	return txt_User_id;
}
public void setTxt_User_id(String txt_User_id) {
	this.txt_User_id = txt_User_id;
}
public String getUSER_STATUS() {
	return USER_STATUS;
}
public void setUSER_STATUS(String uSER_STATUS) {
	USER_STATUS = uSER_STATUS;
}
public String getUSER_ROLE() {
	return USER_ROLE;
}
public void setUSER_ROLE(String uSER_ROLE) {
	USER_ROLE = uSER_ROLE;
}
public String getUSER_ROLE_DESC() {
	return USER_ROLE_DESC;
}
public void setUSER_ROLE_DESC(String uSER_ROLE_DESC) {
	USER_ROLE_DESC = uSER_ROLE_DESC;
}
public String getCREATED_TIME() {
	return CREATED_TIME;
}
public void setCREATED_TIME(String cREATED_TIME) {
	CREATED_TIME = cREATED_TIME;
}
public String getCREATED_USER() {
	return CREATED_USER;
}
public void setCREATED_USER(String cREATED_USER) {
	CREATED_USER = cREATED_USER;
}
public String getLAST_LOGIN_DATE() {
	return LAST_LOGIN_DATE;
}
public void setLAST_LOGIN_DATE(String lAST_LOGIN_DATE) {
	LAST_LOGIN_DATE = lAST_LOGIN_DATE;
}
public String getLAST_LOGIN_IP() {
	return LAST_LOGIN_IP;
}
public void setLAST_LOGIN_IP(String lAST_LOGIN_IP) {
	LAST_LOGIN_IP = lAST_LOGIN_IP;
}
public String getLOGIN_STATUS() {
	return LOGIN_STATUS;
}
public void setLOGIN_STATUS(String lOGIN_STATUS) {
	LOGIN_STATUS = lOGIN_STATUS;
}
public String getLOGIN_RESET() {
	return LOGIN_RESET;
}
public void setLOGIN_RESET(String lOGIN_RESET) {
	LOGIN_RESET = lOGIN_RESET;
}
public String getMODIFIED_USER() {
	return MODIFIED_USER;
}
public void setMODIFIED_USER(String mODIFIED_USER) {
	MODIFIED_USER = mODIFIED_USER;
}
public String getMODIFIED_TIME() {
	return MODIFIED_TIME;
}
public void setMODIFIED_TIME(String mODIFIED_TIME) {
	MODIFIED_TIME = mODIFIED_TIME;
}
public String getUSER_VERIFY() {
	return USER_VERIFY;
}
public void setUSER_VERIFY(String uSER_VERIFY) {
	USER_VERIFY = uSER_VERIFY;
}
public String getUSER_HISTORY() {
	return USER_HISTORY;
}
public void setUSER_HISTORY(String uSER_HISTORY) {
	USER_HISTORY = uSER_HISTORY;
}
public String getISVERIFIED() {
	return ISVERIFIED;
}
public void setISVERIFIED(String iSVERIFIED) {
	ISVERIFIED = iSVERIFIED;
}
public String getEXPIRY_DATE() {
	return EXPIRY_DATE;
}
public void setEXPIRY_DATE(String eXPIRY_DATE) {
	EXPIRY_DATE = eXPIRY_DATE;
}
public String getUser_status_desc() {
	return User_status_desc;
}
public void setUser_status_desc(String user_status_desc) {
	User_status_desc = user_status_desc;
}
public String getP_F_NNUMBER() {
	return P_F_NNUMBER;
}
public void setP_F_NNUMBER(String p_F_NNUMBER) {
	P_F_NNUMBER = p_F_NNUMBER;
}
public String getSOL_ID() {
	return SOL_ID;
}
public void setSOL_ID(String sOL_ID) {
	SOL_ID = sOL_ID;
}
public String getPASSWORD() {
	return PASSWORD;
}
public void setPASSWORD(String pASSWORD) {
	PASSWORD = pASSWORD;
}
public String getPASSWORD_RESET() {
	return PASSWORD_RESET;
}
public void setPASSWORD_RESET(String pASSWORD_RESET) {
	PASSWORD_RESET = pASSWORD_RESET;
}

public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
public String getTxtUserID() {
	return txtUserID;
}
public void setTxtUserID(String txtUserID) {
	this.txtUserID = txtUserID;
}
public String getTxtUserName() {
	return txtUserName;
}
public void setTxtUserName(String txtUserName) {
	this.txtUserName = txtUserName;
}
public String getSelUserStatus() {
	return selUserStatus;
}
public void setSelUserStatus(String selUserStatus) {
	this.selUserStatus = selUserStatus;
}
public String getSelUserRole() {
	return selUserRole;
}
public void setSelUserRole(String selUserRole) {
	this.selUserRole = selUserRole;
}
public String getTxtExpiryDate() {
	return txtExpiryDate;
}
public void setTxtExpiryDate(String txtExpiryDate) {
	this.txtExpiryDate = txtExpiryDate;
}
public String getTxtP_F_Number() {
	return txtP_F_Number;
}
public void setTxtP_F_Number(String txtP_F_Number) {
	this.txtP_F_Number = txtP_F_Number;
}
public String getTxtSolID() {
	return txtSolID;
}
public void setTxtSolID(String txtSolID) {
	this.txtSolID = txtSolID;
}
public String getTxtPassword() {
	return txtPassword;
}
public void setTxtPassword(String txtPassword) {
	this.txtPassword = txtPassword;
}
public String getChkApp() {
	return chkApp;
}
public void setChkApp(String chkApp) {
	this.chkApp = chkApp;
}
public String getChkFolder() {
	return chkFolder;
}
public void setChkFolder(String chkFolder) {
	this.chkFolder = chkFolder;
}
public String getUserName() {
	return UserName;
}
public void setUserName(String userName) {
	UserName = userName;
}
public String getUserID() {
	return UserID;
}
public void setUserID(String userID) {
	UserID = userID;
}
public String getPage() {
	return page;
}
public void setPage(String page) {
	this.page = page;
}
public String getRows() {
	return rows;
}
public void setRows(String rows) {
	this.rows = rows;
}
@Override
public String toString() {
	return "UserMasterBean [UserName=" + UserName + ", UserID=" + UserID + ", page=" + page + ", rows=" + rows + "]";
}
public UserMasterBean() {
	super();
	// TODO Auto-generated constructor stub
}
public UserMasterBean(String userName, String userID, String page, String rows) {
	super();
	UserName = userName;
	UserID = userID;
	this.page = page;
	this.rows = rows;
}
*/

