package com.miscot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DBVaultRestController {
	
	
	/*
	 * @RequestMapping(value = "/StoreAdhVaultRequest", method = RequestMethod.POST)
	 * public @ResponseBody ADHSTRRESP storeAadhar(@RequestBody String reqXML,
	 * HttpServletRequest request) { String output = reqXML; ADHSTRRESPobj=null;
	 * String ipAdd=propertyPath.getIpAddress(); try { ADHSTRRESPobj =
	 * prx.StoreAadhar(output,ipAdd); } catch (Exception e) { e.printStackTrace(); }
	 * return ADHSTRRESPobj; }
	 */
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public @ResponseBody String getByLogin() {
String wish="rest is running";
		System.out.println("Hello");
		return wish;

	}
	
	/*@RequestMapping(value = "/RetrieveAdhVaultRequest", method = RequestMethod.POST)
	public @ResponseBody ADHRTRESP retrieveAadhar(@RequestBody String reqXML, HttpServletRequest request) {
		System.out.println("reqXML::::::::::::"+reqXML);
		String output = reqXML;
		String ipAdd=propertyPath.getIpAddress();
		ADHRTRESPobj = null;
		try {
			ADHRTRESPobj = prx.retriveAdhData(output,ipAdd);
		} catch (Exception e) {
			e.printStackTrace();
		}
   	return ADHRTRESPobj;*/
}