
package com.miscot.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;
import javax.xml.ws.Response;

import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;*/
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.miscot.bean.Question;
import com.miscot.bean.UserMasterBean;
import com.miscot.dto.UserMaster;
import com.miscot.repository.DBUtil;
import com.miscot.service.UserService;
@Controller
public class PasswordController {

	@Autowired
	DBUtil ds;
	  @Autowired 
	  private UserService userService;
	  
 
 @RequestMapping(value = "/questionsSet", method = RequestMethod.GET)
 @ResponseBody
 public String getAllQuestions(HttpServletRequest request) throws SQLException {
	
	String resp=userService.getAllQuestions(request.getParameter("ID"));
	
	return resp;
	 
 }
 
	
	@RequestMapping(value = "/matchAnswers", method = RequestMethod.POST)
	@ResponseBody
	public UserMaster searchUser(HttpServletRequest request)
	{
		boolean resp = false;
		/*try {
			resp = userService.matchForgotPassword(userMasterBean);
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		System.out.println(request.getParameter("ID"));
	return userService.matchForgotPassword(request.getParameter("ID"));
	}
	
}
/*

*/
