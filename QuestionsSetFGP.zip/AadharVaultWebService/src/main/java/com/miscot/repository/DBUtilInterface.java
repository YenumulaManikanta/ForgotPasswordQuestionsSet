package com.miscot.repository;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.miscot.bean.Question;

public interface DBUtilInterface {
//String encrypt(String Data);
	public List<Question> getAllQuestions(String SQL) throws SQLException;
String getSingleValues(String query);
String RemoveNull(String Val) throws Exception;
//String decrypt(String encryptedData);
}
