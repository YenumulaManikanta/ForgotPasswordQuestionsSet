package com.miscot.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GetQueryImpl implements GetQueryInterface {

	@Autowired  
	DBUtil ds;

	public String checkForgetPasswordAnswer(String txt_User_id) {
		// TODO Auto-generated method stub
		String CREATED_USER=ds.getSingleValues("select FP_ANS from tbl_User_master where lower(user_Id)= lower('"+ txt_User_id + "')");
		return CREATED_USER;
	}
}
