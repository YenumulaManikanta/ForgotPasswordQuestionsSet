package com.miscot.service;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import com.miscot.bean.Question;
import com.miscot.bean.UserMasterBean;
import com.miscot.dto.UserMaster;


public interface UserService {
	
 public UserMaster matchForgotPassword(String questionID);
 public String getAllQuestions(String questionID) throws SQLException;
 
}