package com.miscot.service;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.management.Query;

import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miscot.bean.Question;
import com.miscot.bean.UserMasterBean;
import com.miscot.dto.UserMaster;
import com.miscot.repository.DBUtil;
import com.miscot.repository.GetQueryImpl;
@Service("UserServiceImpl")
public class UserServiceImpl implements UserService{
	@Autowired 
	GetQueryImpl getQuery;
	@Autowired
	DBUtil ds;

	@Override
	public String getAllQuestions(String questionID) throws SQLException {

		List<Question> questionList=ds.getAllQuestions(questionID);
		String json="{\r\n";
		for (int i = 0; i < questionList.size(); i++) {
			json+="\"question_set\":";
			json+="{\r\n";
			json+="  \"ques_id\": \""+questionList.get(i).getID()+"\",\r\n" ;
			json+="  \"question\": \""+questionList.get(i).getQUESTION_TEXT()+"\"\r\n" ;
			//json+="  \"ans_datatype\": \""+questionList.get(i).getANSWER_DATATYPE()+"\"\r\n" ;
			json+="}";
		}
		json+="}";
		return json;
	}
	

	public UserMaster matchForgotPassword(String questionID) {
		
		String res=getQuery.checkForgetPasswordAnswer(questionID);
		int ansCount=0;
		List<String> items = Arrays.asList(res.split("\\s*,\\s*"));
		/*
		 * for(int i=0;i<items.size();i++) {
		 * if(items.get(i).equals(userMasterBean.getAns1())) { ansCount++; }
		 * if(items.get(i).equals(userMasterBean.getAns2())) { ansCount++; }
		 * if(items.get(i).equals(userMasterBean.getAns3())) { ansCount++; }
		 * if(ansCount<3) { } }
		 */
		return null;
	}
	
}

